#include <stdio.h>

int main(){
	
	int numero, tabuada;
	
	printf("Digite o numero: \n");
	scanf("%d", &numero);
	
	printf("\n %d x 0 = %d \n-----------", numero, numero * 0);
	printf("\n %d x 1 = %d \n-----------", numero, numero * 1);
	printf("\n %d x 2 = %d \n-----------", numero, numero * 2);
	printf("\n %d x 3 = %d \n-----------", numero, numero * 3);
	printf("\n %d x 4 = %d \n-----------", numero, numero * 4);
	printf("\n %d x 5 = %d \n-----------", numero, numero * 5);
	printf("\n %d x 6 = %d \n-----------", numero, numero * 6);
	printf("\n %d x 7 = %d \n-----------", numero, numero * 7);
	printf("\n %d x 8 = %d \n-----------", numero, numero * 8);
	printf("\n %d x 9 = %d \n-----------", numero, numero * 9);
	printf("\n %d x 10 = %d \n-----------", numero, numero * 10);
	
	return 0;
}
